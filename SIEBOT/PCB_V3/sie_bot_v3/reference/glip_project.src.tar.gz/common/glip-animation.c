/*
 * glip-animation.c
 *
 * This module updates the played animation when YOUARE messages
 * are received. It can change the animation or update the played part
 * according to the new position and/or orientation.
 *
 *
 * Copyright 2010 - Mickaël Camus <mickaelcamus.mc@gmail.com>,
 *                  Enzo Casasola <enzocasasola@gmail.com>,
 *                  Julie Estivie <juliestivie@gmail.com>,
 *                  Florent Matignon <florent.matignon@gmail.com>
 *
 * All rights reserved.
 * GLiP (Great LEDs interactive Puzzle)
 * Telecom ParisTech - ELECINF344/ELECINF381
 *
 * This file is part of GLiP Project.
 *
 * GLiP Project is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * GLiP Project is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with GLiP Project.  If not, see <http://www.gnu.org/licenses/>.
 *
 *
 */

#include <string.h>
// GLiP features
#include "glip-image.h"
#include "glip-animation.h"
#include "synchro.h"
#include "envoi.h"
#include "fatal.h"
#include "constant.h"
#include "animationDescriptor.h"
// Animations' data
#include "catalogue.h"

// Buffer which is read by the glip-image module
unsigned short bufferIMG [MAX_IMAGES * IMAGE_SIZE];

const AnimationDescriptor * currentAnimation;

/*
 *
 * This function is called when a YOUARE message
 * is received ; it should update the played animation
 * if something has changed since the last message.
 *
 */
void animConfig()
{
  // Theses variables store the old block's parameters (from last message)
  static uint8_t myOldMID = 1;
  static uint8_t oldRotation = 0;
  static uint8_t oldNumAnim = 0;

  ENSURE(myMID >= 0);
  ENSURE(rotation >= 0);
  ENSURE(rotation < 4);

  if(numAnim != oldNumAnim) {
    // Update the animation if a new animation should be played
    for(unsigned int i=0;i<=numAnim;i++)
      if(animationList[i] == 0) return;
    // If we're here, the animation exists ; else nothing happens
    currentAnimation = animationList[numAnim];
    oldNumAnim = numAnim;
    oldRotation = ~1;
  }

  if((myMID != myOldMID) || (rotation != oldRotation)) {
    // Update the played part if the position or the direction has changed
    if(myMID > 0) {
      // If we're in the animation, copy the proper image to the buffer
      memcpy (bufferIMG,
              &currentAnimation->data[(myMID-1)*IMAGE_SIZE*(currentAnimation->nb_images)],
              (currentAnimation->nb_images)*IMAGE_SIZE*sizeof(short)
             );
    } else
      // We're outside, nothing should be played
      memset(bufferIMG, 0, MAX_IMAGES*IMAGE_SIZE*sizeof(short));

    // Now, we apply the rotation according to the direction
    for(unsigned int i=0;i<currentAnimation->nb_images;i++)
      rotImage((image_t) &bufferIMG[i*IMAGE_SIZE],rotation);

    // Update parameters
    myOldMID = myMID;
    oldRotation = rotation;

#ifdef MASTER
    // If the desynchronize option is set, we should desynchronize everybody !
    // (and only if current block is master)
    if (currentAnimation->desynchronize)
      desynchronize_world();
#endif
  }
}

/*
 *
 * This function is called at the beginning. We chose to show the
 * first animation in the catalog. This animation could be blank !
 *
 */
void anim_init()
{
  currentAnimation = animationList[0];
  animConfig();
}
