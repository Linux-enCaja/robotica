/*
 * irda.c
 *
 * This module configures the different USARTs in order to use Infrared Communication.
 * Each module can be configured to use the USART1 as a debug port or as an infrared port.
 * In the actual version, the master block communicates with the others thanks to the debug port.
 *
 * Each USART port uses a queue for the reception and a second one for the transmission.
 * A task creates the different packets and put them in a treatment queue.
 *
 *
 * Copyright 2010 - Mickaël Camus <mickaelcamus.mc@gmail.com>,
 *                  Enzo Casasola <enzocasasola@gmail.com>,
 *                  Julie Estivie <juliestivie@gmail.com>,
 *                  Florent Matignon <florent.matignon@gmail.com>
 *
 * All rights reserved.
 * GLiP (Great LEDs interactive Puzzle)
 * Telecom ParisTech - ELECINF344/ELECINF381
 *
 * This file is part of GLiP Project.
 *
 * GLiP Project is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * GLiP Project is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with GLiP Project.  If not, see <http://www.gnu.org/licenses/>.
 *
 *
 */


// FreeRTOS and STM32 features
#include <stm32f10x.h>
#include <FreeRTOS.h>
#include <task.h>
#include <queue.h>

// GLiP features
#include "irda.h"
#include "fatal.h"
#include "constant.h"
#include "checksum.h"
#include "glip-image.h"

// Declaration of the reception, transmission and treatment queues
static xQueueHandle xQueueRead [4];
static xQueueHandle xQueueWrite [4];
xQueueHandle xQueuePaquet ;

// Packets used for the reception
static Paquet usartPacket [4];

// Semaphore used for the transmit function
xSemaphoreHandle xSemaphoreTransmit;

/*
 *
 * This function configures the USARTs from n to 4
 * to be used as IrDA ports
 *
 */
static void configureIRDA(int n) {

  static const int interrupt [4] = {37,38,39,52};
  static const int shift [4] = {1<<5,1<<6,1<<7,1<<20};

  USART_TypeDef* UART;

  //Configure U(S)ART n
  switch(n) {
    case 1:
      UART = USART1;
      // Configuration of ports PA9, PA10
      GPIOA->CRH = (GPIOA->CRH & ~(0x000000F0)) | 0x000000B0;
      GPIOA->CRH = (GPIOA->CRH & ~(0x00000F00)) | 0x00000800;
      // Forcing the pull-up
      GPIOA->BSRR = (1 << 10);
      break;
    case 2:
      UART = USART2;
      // Configuration of ports PA2, PA3
      GPIOA->CRL = (GPIOA->CRL & ~(0x00000F00)) | 0x00000B00;
      GPIOA->CRL = (GPIOA->CRL & ~(0x0000F000)) | 0x00008000;
      // Forcing the pull-up
      GPIOA->BSRR = (1 << 3);
      break;
    case 3:
      UART = USART3;
      // Configuration of ports PB10, PB11
      GPIOB->CRH = (GPIOB->CRH & ~(0x00000F00)) | 0x00000B00;
      GPIOB->CRH = (GPIOB->CRH & ~(0x0000F000)) | 0x00008000;
      // Forcing the pull-up
      GPIOB->BSRR = (1 << 11);
      break;
    case 4:
      UART = UART4;
      // Configuration of ports PC10, PC11
      GPIOC->CRH = (GPIOC->CRH & ~(0x00000F00)) | 0x00000B00;
      GPIOC->CRH = (GPIOC->CRH & ~(0x0000F000)) | 0x00008000;
      // Forcing the pull-up
      GPIOC->BSRR = (1 << 11);
      break;
    default:
      UART = 0;
  }

  ENSURE(UART);

  // Setting up CR2
  UART->CR2 &= ~(1 << 11) // CLKEN 0
               & ~(3 << 12) // STOP 1 bit
               & ~(1 << 14); // LINEN 0

  // Setting up CR3
  UART->CR3 &= ~(1 << 5) // SCEN 0
               & ~(1 << 3); // HDSEL 0

  // Normal IrDA mode -> PSC = 00000001
  UART->GTPR = (UART->GTPR & 0xFFFFFF00) | 0x00000001;

  // Baud rate 115.2Kbps
  if (n == 1)
    UART->BRR = 0x0271;
  else
    UART->BRR = 0x0138;

  // Setting the IrDA
  UART->CR3 |= (1 << 1);

  // Mode 8N1
  UART->CR1 = (0 << 12) // 8 bits wordsts
              | (0 << 10) // No parity
              | (1 << 13) // Activate USART
              | (1 << 5) // IRQ on reception
              | (0 << 7); // No IRQ on writing

  // Activating interruptions for reception
  NVIC->IP[interrupt[n-1]] = 254;
  NVIC->ISER[1] |= shift[n-1];

  // Activating interruptions for writing
  UART->CR1 |= (1 << 3);

  // Activating of the reception
  UART->CR1 |= (1 << 2);

  // Initialization of queues
  xQueueRead[n-1]  = xQueueCreate (128, sizeof(char));
  xQueueWrite[n-1] = xQueueCreate (128, sizeof(char));

  ENSURE(xQueueRead[n-1]);
  ENSURE(xQueueWrite[n-1]);
}


/*
 *
 * This function initializes the clocks of the U(S)ARTs
 * and the treatment queue.
 * Then it calls the previous function to configure each U(S)ART.
 *
 */
void initIRDA (int n) {

  // Clocks initialization
  RCC->APB2ENR |= (1 << 2) // IOPAEN
                  | (1 << 3) // IOPBEN
                  | (1 << 4) // IOPCEN
                  | (1 << 0) // AFIOEN
                  | (1 << 14); //USART1EN

  RCC->APB1ENR |= (1 << 17) // USART2EN
                  | (1 << 18) // USART3EN
                  | (1 << 19); // UART4EN

  // Treatment queue initialization
  xQueuePaquet = xQueueCreate (12, sizeof(Paquet));
  ENSURE(xQueuePaquet);

  // Transmission mutex initialization
  xSemaphoreTransmit = xSemaphoreCreateMutex();
  ENSURE(xSemaphoreTransmit);

  // Configure U(S)ARTs from n to 4
  for (unsigned int i = n; i < 5; i++)
    configureIRDA (i);

}

/*
 *
 * The master block must be initialize with the USART1 configured as a serial port.
 * If MASTER is not defined, we use this port as an IrDA port.
 * This function is the handler of the USART1. It puts a new character in the reception queue
 * or it takes a character in the transmission queue and transmits it.
 *
 */
#ifndef MASTER
void USART1_IRQHandler () {
  portBASE_TYPE resched_needed = pdFALSE;

  char c;

  if (USART1->SR & (1 << 5)) {
    // Put the character in the reception queue
    c = USART1->DR;
    xQueueSendFromISR ( xQueueRead [0], &c, &resched_needed );
  }
  else if (USART1->SR & (1 << 7)) {

    // Write a character in the register DR
    if(xQueueReceiveFromISR( xQueueWrite [0], &c, &resched_needed ) == pdTRUE) {
      USART1->DR = c;
    }
    else
      // Stopping writing interruptions
      USART1->CR1 &= ~(1 << 7);
  }

  portEND_SWITCHING_ISR (resched_needed);
}
#endif

// Handler for USART2 interruptions
void USART2_IRQHandler () {
  portBASE_TYPE resched_needed = pdFALSE;

  char c;

  if (USART2->SR & (1 << 5)) {
    // Put the character in the reception queue
    c = USART2->DR;
    xQueueSendFromISR ( xQueueRead [1], &c, &resched_needed );
  }
  else if (USART2->SR & (1 << 7)) {
    // Write a character in the register DR
    if(xQueueReceiveFromISR( xQueueWrite [1], &c, &resched_needed ) == pdTRUE) {
      USART2->DR = c;
    }
    else
      // Stopping writing interruptions
      USART2->CR1 &= ~(1 << 7);
  }

  portEND_SWITCHING_ISR (resched_needed);
}

// Handler for USART3 interruptions
void USART3_IRQHandler () {
  portBASE_TYPE resched_needed = pdFALSE;

  char c;

  if (USART3->SR & (1 << 5)) {
    // Put the character in the reception queue
    c = USART3->DR;
    xQueueSendFromISR ( xQueueRead[2], &c, &resched_needed );
  }
  else if (USART3->SR & (1 << 7)) {
    // Write a character in the register DR
    if(xQueueReceiveFromISR( xQueueWrite[2], &c, &resched_needed ) == pdTRUE) {
      USART3->DR = c;
    }
    else
      // Stopping writing interruptions
      USART3->CR1 &= ~(1 << 7);
  }

  portEND_SWITCHING_ISR (resched_needed);
}

// Handler for UART4 interruptions
void UART4_IRQHandler () {
  portBASE_TYPE resched_needed = pdFALSE;

  char c;

  if (UART4->SR & (1 << 5)) {
    // Put the character in the reception queue
    c = UART4->DR;
    xQueueSendFromISR ( xQueueRead[3], &c, &resched_needed );
  }
  else if (UART4->SR & (1 << 7)) {
    // Write a character in the register DR
    if(xQueueReceiveFromISR( xQueueWrite[3], &c, &resched_needed ) == pdTRUE) {
      UART4->DR = c;
    }
    else
      // Stopping writing interruptions
      UART4->CR1 &= ~(1 << 7);
  }

  portEND_SWITCHING_ISR (resched_needed);
}


/*
 *
 * This function is the state machine which tries to create a new packet
 * with the characters received on the U(S)ART.
 *
 * The packet must begin with the "GLiP" string.
 *
 * If a packet is complete and if its checksum is correct, the packet is
 * put in the treatment queue.
 *
 */
void writeReadDataIrda (void *pvParameters) {

  char c;

  int index = 0;
  char command[4];
  unsigned int uartn = (unsigned int) pvParameters;
  ENSURE(uartn<5);

  int indexData = 0;

  ETAT state = STATE_IDLE;

  ENSURE(xQueueRead[uartn-1]);

  for ( ;; ) {
    // Wait for a new character
    xQueueReceive( xQueueRead [uartn-1], &c, portMAX_DELAY);

    command[index] = c;
    index++;
    index = index % 4;

    // Calculate the new state
    newState (&usartPacket[uartn-1], &state, &indexData, index, command, c, uartn);
  }
}

/*
 *
 * This function calculate the next state of the state machine.
 *
 */
void newState (Paquet * packet, ETAT * state, int * indexData, int index, char command [], char c, int uart)
{
  int check = -1;

  ENSURE(packet);
  ENSURE(state);
  ENSURE(indexData);
  ENSURE((*indexData)>=0);
  ENSURE(*indexData < MAX_DATA_SIZE);

  if (command[index] == 'G'
      && command[(index+1)%4] == 'L'
      && command[(index+2)%4] == 'i'
      && command[(index+3)%4] == 'P') {
    // A new packet comes in...
    (*state) = STATE_IDPF;
    (*indexData) = 0;
  }
  else {
    switch (*state) {
      case STATE_IDPF:
        packet->idPaquets = (c << 8);
        (*state)++;
        break;
      case STATE_IDPN:
        packet->idPaquets |= c;
        (*state)++;
        break;
      case STATE_FROM:
        packet->from = c;
        (*state)++;
        break;
      case STATE_TTL:
        packet->ttl = c;
        (*state)++;
        break;
      case STATE_MODE:
        packet->mode = c;
        (*state)++;
        break;
      case STATE_DATA:
        (packet->data)[*indexData] = c;
        (*indexData)++;
        // Loop if there are other data
        if (packet->mode != 'D')
          (*state) = (*indexData == MAX_COMMAND_SIZE) ? ((*state) + 1) : (*state);
        else
          (*state) = (*indexData == MAX_DATA_SIZE) ? ((*state) + 1) : (*state);
        break;
      case STATE_CHECK1:
        packet->checksum = (c << 8);
        (*state)++;
        break;
      case STATE_CHECK2:
        packet->checksum |= c;
        (*state) = STATE_IDLE;

        // Checking packet's integrity
        check = calculateCRC16Paquet (packet, 1);

        if (check == 0) {
          // If the packet is ok, we put it in the treatment queue
          ENSURE(MAX_DATA_SIZE > 20);
          packet->data[20] = uart;
          xQueueSend (xQueuePaquet, packet,0);
        }
        break;
      default:
	(*state) = STATE_IDLE;
	break;
    }
  }

}


/*
 *
 * The three functions below send a character, a short or a string
 * on the U(S)ART nUSART.
 *
 * To write a short or a string we use the character sending function.
 *
 */
void writeCharIrda (char c, unsigned int nUSART) {
  ENSURE(nUSART >= IRDA_MIN);
  ENSURE(nUSART < 5);

  // Put the character in the queue
  xQueueSend ( xQueueWrite [nUSART-1], &c, portMAX_DELAY );

  // Activating interruptions for writing
  switch (nUSART) {
    case 1:
      USART1->CR1 |= (1 << 7);
      break;
    case 2:
      USART2->CR1 |= (1 << 7);
      break;
    case 3:
      USART3->CR1 |= (1 << 7);
      break;
    case 4:
      UART4->CR1 |= (1 << 7);
      break;
  }
}

void writeShortIrda (unsigned short s, unsigned int nsUART) {
  writeCharIrda(s >> 8, nsUART);
  writeCharIrda(s & 0xff, nsUART);
}

void writeDataIrda (const char *s, unsigned int nUSART, unsigned int size) {
  for (unsigned int i = 0;i < size; i++)
    writeCharIrda(s[i], nUSART);
}
