#ifndef _SYNCHRO_H_
#define _SYNCHRO_H_

/*
 * synchro.h
 *
 * This module is used to synchronize all the blocks together. A timer
 * has the current hour of the block. When a certain type of message is
 * received, the local clock is changed to the one gived in the message.
 *
 *
 * Copyright 2010 - Mickaël Camus <mickaelcamus.mc@gmail.com>,
 *                  Enzo Casasola <enzocasasola@gmail.com>,
 *                  Julie Estivie <juliestivie@gmail.com>,
 *                  Florent Matignon <florent.matignon@gmail.com>
 *
 * All rights reserved.
 * GLiP (Great LEDs interactive Puzzle)
 * Telecom ParisTech - ELECINF344/ELECINF381
 *
 * This file is part of GLiP Project.
 *
 * GLiP Project is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * GLiP Project is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with GLiP Project.  If not, see <http://www.gnu.org/licenses/>.
 *
 *
 */

#include <stdint.h>

/*
 *
 * Return the local clock
 *
 */
static inline uint32_t current_time()
{
  extern volatile uint32_t time_counter;
  return time_counter;
}

void adjust_current_time(uint32_t new_time);
void time_init();

#endif // _SYNCHRO_H_
