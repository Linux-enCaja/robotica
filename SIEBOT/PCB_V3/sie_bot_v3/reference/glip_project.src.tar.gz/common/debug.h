#ifndef _DEBUG_H_
#define _DEBUG_H_


/*
 * debug.h
 *
 * This file is used for the management of the USART1 as a serial debug port.
 * It is also used by the master block which is commanded through a serial port.
 * The functions above configures this port correctly and offers the possibility
 * of writing characters, numbers and strings.
 * There is a task which read the message received on USART1 and which
 * interprets these message as command if possible.
 *
 *
 * Copyright 2010 - Mickaël Camus <mickaelcamus.mc@gmail.com>,
 *                  Enzo Casasola <enzocasasola@gmail.com>,
 *                  Julie Estivie <juliestivie@gmail.com>,
 *                  Florent Matignon <florent.matignon@gmail.com>
 *
 * All rights reserved.
 * GLiP (Great LEDs interactive Puzzle)
 * Telecom ParisTech - ELECINF344/ELECINF381
 *
 * This file is part of GLiP Project.
 *
 * GLiP Project is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * GLiP Project is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with GLiP Project.  If not, see <http://www.gnu.org/licenses/>.
 *
 *
 */

// Number of the currently played animation
extern uint8_t numAnim;

void initDebug ();
void writeDebug (const char *);
void writeCharDebug (char);
void writeHexDebug(unsigned char);
void writeHexStrDebug(const char *prefix,
           const char *str, unsigned int length);

void receiveDebug();

#endif
