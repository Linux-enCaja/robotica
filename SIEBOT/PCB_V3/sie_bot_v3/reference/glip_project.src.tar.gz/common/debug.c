/*
 * debug.c
 *
 * This file is used for the management of the USART1 as a serial debug port.
 * It is also used by the master block which is commanded through a serial port.
 * The functions above configures this port correctly and offers the possibility
 * of writing characters, numbers and strings.
 * There is a task which read the message received on USART1 and which
 * interprets these message as command if possible.
 *
 *
 * Copyright 2010 - Micka�l Camus <mickaelcamus.mc@gmail.com>,
 *                  Enzo Casasola <enzocasasola@gmail.com>,
 *                  Julie Estivie <juliestivie@gmail.com>,
 *                  Florent Matignon <florent.matignon@gmail.com>
 *
 * All rights reserved.
 * GLiP (Great LEDs interactive Puzzle)
 * Telecom ParisTech - ELECINF344/ELECINF381
 *
 * This file is part of GLiP Project.
 *
 * GLiP Project is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * GLiP Project is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with GLiP Project.  If not, see <http://www.gnu.org/licenses/>.
 *
 *
 */

// FreeRTOS and STM32 features
#include <stm32f10x.h>
#include <FreeRTOS.h>
#include <task.h>
#include <queue.h>

// GLiP features
#include "debug.h"
#include "fatal.h"
#include "glip-animation.h"

// Definition of the read queue
static xQueueHandle xQueueReadDebug;


/*
 *
 * This function configures the USART1 to use it as a serial
 * debug port.
 *
 */
void initDebug () {

  RCC->APB2ENR |= (1 << 2); // Port A
  RCC->APB2ENR |= (1 << 14); // USART1

  // Clocks initialization
  RCC->APB2ENR |= (1 << 14) | (1 << 2) | (1 << 0);

  // Port configuration
  GPIOA->CRH = (GPIOA->CRH & ~(0x000000F0)) | 0x000000B0;
  GPIOA->CRH = (GPIOA->CRH & ~(0x00000F00)) | 0x00000800;

  // Forcing the pull-up
  GPIOA->BSRR = 1<<10;

  // Setting up CR2
  USART1->CR2 &= ~(3 << 12); // STOP 1 bit

  // Baud rate 115.2Kbps
  USART1->BRR = 0x0271;

  // 8N1 mode
  USART1->CR1 = (0 << 12) // 8 bits words
                | (0 << 10) // No parity
                | (1 << 13) // Activating USART1
                | (1 << 5) // Reading IRQ
                | (0 << 7); // No writing IRQ

  // Setting reading interruption
  NVIC->IP[37] = 254;
  NVIC->ISER[1] |= (1 << 5);

  // Writing activation
  USART1->CR1 |= (1 << 3);

  // Reading activation
  USART1->CR1 |= (1 << 2);

  // Queue initialization
  xQueueReadDebug = xQueueCreate(50,sizeof(char));
  ENSURE(xQueueReadDebug);
}

/*
 *
 * If the block is the master block, we configure the IRQHandler
 * for the serial port else it will be configured for IrDA.
 *
 */
#ifdef MASTER
void USART1_IRQHandler() {
  portBASE_TYPE resched_needed = pdFALSE;

  char c;
  if(USART1->SR & (1<<5)) {
    c = USART1->DR;
    xQueueSendFromISR(xQueueReadDebug,&c,&resched_needed);
  }
  portEND_SWITCHING_ISR(resched_needed);
}
#endif

/*
 *
 * This function tries to find a command in the characters
 * which are received on the USART1.
 *
 */
void receiveDebug() {
  static char c;
  static unsigned int animNumber;
  static unsigned int allow = 0;
  for(;;) {
    xQueueReceive(xQueueReadDebug,&c,portMAX_DELAY);

    // 'C' : select an animation
    if(c == 'C') {
        allow = 1;
        animNumber = 0;
    }
    // Number of the animation
    else if ((c >= '0') && (c <= '9') && allow)
      animNumber = animNumber*10 + c-'0';
    // The number is confirmed, we change the animation
    else if (((c == '\r') || (c == '\n')) && allow && (animNumber > 0)) {
      allow = 0;
      writeDebug("Starting ANIM ");
      writeHexDebug(animNumber);
      writeDebug("\r\n");
      numAnim = animNumber-1;
      animConfig();
    }
    // 'L' : list available animations
    else if (c == 'L') {
      writeDebug("Available animations:\r\n");
      for(unsigned int i=0;animationList[i];i++) {
        writeDebug("- ");
        writeHexDebug(i+1);
        writeDebug(": ");
        writeDebug((const char *)animationList[i]->name);
        writeDebug("\r\n");
      }
    }
    // 'N' : play the next animation
    // Notice that numAnim is always incremeted even if it is over the maximum number
    else if(c == 'N') {
      writeDebug("Next ANIM\r\n");
      numAnim++;
      animConfig();
    }
    // 'P' : play the previous animation
    else if(c == 'P') {
      if(numAnim > 0) {
        writeDebug("Previous ANIM\r\n");
        numAnim--;
        animConfig();
      } else {
        writeDebug("No previous anim...\r\n");
      }
    }
    // 'R' : reset block
    else if(c == 'R') {
      SCB->AIRCR = 0x05FA0004;
      for(;;);
    }
  }
}

/*
 *
 * This function write the character c on the serial port
 * We don't use interrupts for writing as far as it is not
 * used that much...
 *
 */
void writeCharDebug (char c) {

  while (!(USART1->SR & (1 << 7)));

   USART1->DR = c;
}

/*
 *
 * This function writes the string s on the serial port
 *
 */
void writeDebug (const char * s) {
  // Write each character
  for (;*s;s++)
    writeCharDebug (*s);

}

/*
 *
 * This function writes the nibble c on the serial port
 *
 */
static void writeNibbleDebug(unsigned char c)
{
    writeCharDebug(c >= 10 ? 'A' - 10 + c : '0' + c);
}

/*
 *
 * This function writes the number c in hexa on the serial port
 *
 */
void writeHexDebug(unsigned char c)
{
    writeNibbleDebug(c >> 4);
    writeNibbleDebug(c & 0xf);
}

/*
 *
 * This function writes the string :
 *    prefix + number str in hexa
 * on the serial port
 *
 */
void writeHexStrDebug(const char *prefix,
           const char *str, unsigned int length)
{
    writeDebug(prefix);
    for (unsigned int i = 0; i < length; i++) {
        writeCharDebug(' ');
        writeHexDebug(str[i]);
    }
    writeDebug("\r\n");
}
