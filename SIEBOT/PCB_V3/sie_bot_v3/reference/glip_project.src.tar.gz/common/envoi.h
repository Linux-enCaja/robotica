#ifndef _envoi_h_
#define _envoi_h_

/*
 * envoi.h
 *
 * This module is used to send the different types of messages. It includes a
 * function that determines the ID of the blocks by looking in the array below.
 *
 * Copyright 2010 - Micka�l Camus <mickaelcamus.mc@gmail.com>,
 *                  Enzo Casasola <enzocasasola@gmail.com>,
 *                  Julie Estivie <juliestivie@gmail.com>,
 *                  Florent Matignon <florent.matignon@gmail.com>
 *
 * All rights reserved.
 * GLiP (Great LEDs interactive Puzzle)
 * Telecom ParisTech - ELECINF344/ELECINF381
 *
 * This file is part of GLiP Project.
 *
 * GLiP Project is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * GLiP Project is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with GLiP Project.  If not, see <http://www.gnu.org/licenses/>.
 *
 *
 */

#include <stdint.h>
#include "paquet.h"
#include "animationDescriptor.h"

// This address gives the unique ID of the stm32
#define ID_ADDR    (*((volatile unsigned long *) 0x1FFFF7F0))

extern uint8_t rotation;
extern uint8_t myID,myMID;
extern uint8_t numAnim;

void send_neighbours(uint8_t YouAreID);
uint8_t which_is_myID();

void send_to_destination(Paquet *paquet);
void send_to_master(Paquet *paquet);

#ifdef MASTER
void desynchronize_world();
#endif

#endif
