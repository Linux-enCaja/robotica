/*
 * paquet.c
 *
 * This module contains all the necessary for the packet management.
 * There are functions for :
 *     - creation
 *     - initialization
 *     - transmission
 * Be careful to see the constant for the MAX_SIZE of the commands and
 * data.
 *
 *
 * Copyright 2010 - Micka�l Camus <mickaelcamus.mc@gmail.com>,
 *                  Enzo Casasola <enzocasasola@gmail.com>,
 *                  Julie Estivie <juliestivie@gmail.com>,
 *                  Florent Matignon <florent.matignon@gmail.com>
 *
 * All rights reserved.
 * GLiP (Great LEDs interactive Puzzle)
 * Telecom ParisTech - ELECINF344/ELECINF381
 *
 * This file is part of GLiP Project.
 *
 * GLiP Project is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * GLiP Project is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with GLiP Project.  If not, see <http://www.gnu.org/licenses/>.
 *
 *
 */

// GLiP features
#include "paquet.h"
#include "irda.h"
#include "checksum.h"
#include "fatal.h"
#include "debug.h"
#include "envoi.h"

/*
 *
 * This function initialize a packet by setting all the fields
 * to 0.
 *
 */
void initPaquet (Paquet * packet) {

  ENSURE(packet);

  packet->idPaquets = 0;
  packet->from      = 0;
  packet->ttl       = 0;
  packet->mode      = 0;
  packet->checksum  = 0;

  for (unsigned int i = 0; i < MAX_DATA_SIZE; i++)
    (packet->data)[i] = 0;

}


/*
 *
 * This function fills a packet with :
 *     - its new id : idPaquets
 *     - the transmitter : from
 *     - the ttl : ttl
 *     - the mode : see the constant.h file to view availabled modes
 *     - the data.
 * Next, it calculates the checksum of the packet and put it in it.
 *
 */
void makePaquet (Paquet * packet, uint16_t idPaquets, uint8_t from,
                 uint8_t ttl, uint8_t mode,
                 const uint8_t * data)
{
  packet->idPaquets = idPaquets;
  packet->from      = from;
  packet->ttl       = ttl;
  packet->mode      = mode;

  unsigned int max = mode == 'D' ? MAX_DATA_SIZE : MAX_COMMAND_SIZE;
  memcpy(packet->data,data,max);

  calculateCRC16Paquet (packet, 0);
}

/*
 *
 * This function sends a packet on the interface specified in the field interface.
 *
 */
void transmitPaquet (const Paquet * packet, int interface) {
  // Check if the interface is available
  if (interface < IRDA_MIN)
    return;

  xSemaphoreTake (xSemaphoreTransmit, portMAX_DELAY);

  // A packet comes out...
  writeDataIrda ("GLiP", interface, 4);
  writeShortIrda(packet->idPaquets, interface);
  writeCharIrda (packet->from, interface);
  writeCharIrda ((packet->ttl), interface);
  writeCharIrda ((packet->mode), interface);

  unsigned int max = packet->mode == 'D' ? MAX_DATA_SIZE : MAX_COMMAND_SIZE;
  writeDataIrda((const char *) packet->data, interface, max);

  writeShortIrda(packet->checksum, interface);

  xSemaphoreGive (xSemaphoreTransmit);
}
