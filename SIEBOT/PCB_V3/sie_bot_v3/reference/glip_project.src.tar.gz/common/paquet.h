#ifndef _PAQUET_H_
#define _PAQUET_H_

/*
 * paquet.h
 *
 * This module contains all the necessary for the packet management.
 * There are functions for :
 *     - creation
 *     - initialization
 *     - transmission
 * Be careful to see the constant for the MAX_SIZE of the commands and
 * data.
 *
 *
 * Copyright 2010 - Mickaël Camus <mickaelcamus.mc@gmail.com>,
 *                  Enzo Casasola <enzocasasola@gmail.com>,
 *                  Julie Estivie <juliestivie@gmail.com>,
 *                  Florent Matignon <florent.matignon@gmail.com>
 *
 * All rights reserved.
 * GLiP (Great LEDs interactive Puzzle)
 * Telecom ParisTech - ELECINF344/ELECINF381
 *
 * This file is part of GLiP Project.
 *
 * GLiP Project is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * GLiP Project is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with GLiP Project.  If not, see <http://www.gnu.org/licenses/>.
 *
 *
 */

// GLiP features
#include "constant.h"
#include <stdint.h>

// Definition of the packet structure
typedef struct paquets {

    // ID of the packet : ID of the sender + Number of the packet
    uint16_t idPaquets;

    // ID of the sender
    uint8_t from;

    // Time To Live
    uint8_t ttl;

    // Mode : command or data
    uint8_t mode;

    // Data of the packet
    uint8_t data [MAX_DATA_SIZE];

    // Checksum CRC16
    uint16_t checksum;

} Paquet;

void initPaquet (Paquet*);

void makePaquet (Paquet*, uint16_t, uint8_t, uint8_t, uint8_t, const uint8_t*);
void transmitPaquet (const Paquet *, int);

#endif
