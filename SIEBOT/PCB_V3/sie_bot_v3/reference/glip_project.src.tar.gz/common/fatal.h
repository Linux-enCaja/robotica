#ifndef _FATAL_H_
#define _FATAL_H_

/*
 * fatal.h
 *
 * This module is used for debug.
 *
 *
 * Copyright 2010 - Alexis Polti <alexis.polti@telecom-paristech.fr>
 *
 * All rights reserved.
 * GLiP (Great LEDs interactive Puzzle)
 * Telecom ParisTech - ELECINF344/ELECINF381
 *
 * This file is part of GLiP Project.
 *
 * GLiP Project is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * GLiP Project is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with GLiP Project.  If not, see <http://www.gnu.org/licenses/>.
 *
 *
 */

void fatal_error(const char* nom_fichier, unsigned int line) __attribute__((noreturn));

#ifdef DEBUG_CHECK
#define ENSURE(x) do { if(!(x)) fatal_error(__FILE__, __LINE__); } while(0)
#else
#define ENSURE(x)
#endif

#endif
