#ifndef _IRDA_H_
#define _IRDA_H_

/*
 * irda.h
 *
 * This module configure the different USARTs in order to use Infrared Communication.
 * Each module can be configured to use the USART1 as a debug port or as an infrared port.
 * In the actual version, the master block communicates with the others thanks to the debug port.
 *
 * Each USART port uses a queue for the reception and a second one for the transmission.
 * A task creates the different packets and put them in a treatment queue.
 *
 *
 * Copyright 2010 - Mickaël Camus <mickaelcamus.mc@gmail.com>,
 *                  Enzo Casasola <enzocasasola@gmail.com>,
 *                  Julie Estivie <juliestivie@gmail.com>,
 *                  Florent Matignon <florent.matignon@gmail.com>
 *
 * All rights reserved.
 * GLiP (Great LEDs interactive Puzzle)
 * Telecom ParisTech - ELECINF344/ELECINF381
 *
 * This file is part of GLiP Project.
 *
 * GLiP Project is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * GLiP Project is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with GLiP Project.  If not, see <http://www.gnu.org/licenses/>.
 *
 *
 */

// FreeRTOS and STM32 features
#include <FreeRTOS.h>
#include <task.h>
#include <semphr.h>

// GLiP features
#include "paquet.h"

// Semaphore used for the transmit function
extern xSemaphoreHandle xSemaphoreTransmit;

/*
 *
 * Declaration of the different states for the state machine.
 *
 */
typedef enum {
   STATE_IDLE   = -1,
   STATE_IDPF   =  0,
   STATE_IDPN   =  1,
   STATE_FROM   =  2,
   STATE_TTL    =  3,
   STATE_MODE   =  4,
   STATE_DATA   =  5,
   STATE_CHECK1 =  6,
   STATE_CHECK2 =  7
} ETAT;


void initIRDA (int);

void writeReadDataIrda (void *);
void newState (Paquet*, ETAT *, int*, int, char*, char, int);

void writeDataIrda (const char *s, unsigned int nsUART, unsigned int size);
void writeCharIrda (char c, unsigned int nsUART);
void writeShortIrda (unsigned short s, unsigned int nsUART);

#endif
