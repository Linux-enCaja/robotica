#ifndef _constant_h_
#define _constant_h_

/*
 * constant.h
 *
 * In this file, the constants of the project are defined
 * for a 4x4 blocks game maximum.
 * They must be adapted to each configuration.
 *
 * Copyright 2010 - Mickaël Camus <mickaelcamus.mc@gmail.com>,
 *                  Enzo Casasola <enzocasasola@gmail.com>,
 *                  Julie Estivie <juliestivie@gmail.com>,
 *                  Florent Matignon <florent.matignon@gmail.com>
 *
 * All rights reserved.
 * GLiP (Great LEDs interactive Puzzle)
 * Telecom ParisTech - ELECINF344/ELECINF381
 *
 * This file is part of GLiP Project.
 *
 * GLiP Project is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * GLiP Project is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with GLiP Project.  If not, see <http://www.gnu.org/licenses/>.
 *
 *
 */

// Size of the command packet
#define MAX_COMMAND_SIZE 8

// Size of the data packet
#define MAX_DATA_SIZE 22

// Number of max blocks
#define MAX_NODES 20

// Are we in debug mode ?
#ifndef IRDA_MIN
#define IRDA_MIN 1
#endif

#define IMAGE_SIZE 64

/*
 *
 * Messages' format :
 *
 *   - YOUARE msgId(1) blocId(1) messageDirection(1)
 *        Say to a specific block who he is and from which direction he received this message
 *        (HORIZONTAL or VERTICAL). These messages are only transmitted to the neighbours who
 *        have a superior ID, i.e. to the right or to the bottom. If the blockId is 0, it means
 *        that the block is not in the current animation.
 *        The msgId field means that a block must treat only one message in a emission (indeed
 *        messages are transmitted by 10 at a time). If the block receives more than one packet
 *        of the same emission he mustn't transmit it to his neighbours.
 *   - PING msgId(1) target(1) opaque(4)
 *        The addresse of this message is the block target. If the block has a lower ID than target
 *        he must transmit it to his neighbours who can be on the way of the target.
 *        When this message is received by a block, target answers with a PONG message. Be careful
 *        that the msgId is specific to each packet type.
 *   - PONG msgId(1) source(1) opaque(4)
 *        This the answer to a PING packet. It is always transmit on the up and left ports.
 *   - YOURTIME msgId(1) target(1) hour(4)
 *        This message is routed as a PING message. It says to a block what is its hour (on 32 bits).
 *
 */

typedef enum {
  BROADCAST,
  YOUARE,
  PING,
  PONG,
  YOURTIME
} command_t;

typedef enum {
  HORIZONTAL = 0,
  VERTICAL   = 1
} orientation_t;

#endif
