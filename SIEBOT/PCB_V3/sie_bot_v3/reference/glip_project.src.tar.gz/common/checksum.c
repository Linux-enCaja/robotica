/*
 * checksum.c
 *
 * This module calculates the checksum of a packet. The checksum used is a CRC16
 * MODBUS checksum.
 * We use the polynom 0xA001 and the initialization value is 0xFFFF.
 *
 *
 * Copyright 2010 - Mickaël Camus <mickaelcamus.mc@gmail.com>,
 *                  Enzo Casasola <enzocasasola@gmail.com>,
 *                  Julie Estivie <juliestivie@gmail.com>,
 *                  Florent Matignon <florent.matignon@gmail.com>
 *
 * All rights reserved.
 * GLiP (Great LEDs interactive Puzzle)
 * Telecom ParisTech - ELECINF344/ELECINF381
 *
 * This file is part of GLiP Project.
 *
 * GLiP Project is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * GLiP Project is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with GLiP Project.  If not, see <http://www.gnu.org/licenses/>.
 *
 *
 */

// GLiP features
#include "checksum.h"
#include "constant.h"

#include <stdio.h>
#include <stdint.h>

static void calculateCRC16_Modbus (unsigned char val, uint16_t *crc16) {
  *crc16 ^= val;

  for (unsigned int i=0; i<8; i++) {
    unsigned int carry = (*crc16) & 0x0001;
    *crc16 >>= 1;
    if (carry)
      *crc16 ^= 0xA001;
  }
}

// Macro for adding one or two bytes to the checksum
#define CRC(x)  calculateCRC16_Modbus ((x), &crc16)
#define CRC2(x) do {calculateCRC16_Modbus ((x)&0xff, &crc16); calculateCRC16_Modbus (((x)>>8)&0xff, &crc16); } while(0)


/*
 *
 * This function calculate the checksum of a packet.
 *
 * If check is set, it adds the current checksum and checks if the returned value is 0
 * else it puts the computed checksum in the checksum field of the packet.
 *
 */
int calculateCRC16Paquet (Paquet * packet, int check) {

  // Initialization of the crc
  uint16_t crc16 = 0xFFFF;

  CRC2(packet->idPaquets);
  CRC(packet->from);
  CRC(packet->ttl);
  CRC(packet->mode);

  unsigned int max = packet->mode == 'D' ? MAX_DATA_SIZE : MAX_COMMAND_SIZE;
  for (unsigned int i=0; i<max; i++)
    CRC(packet->data[i]);

  if (check)
    CRC2(packet->checksum);

  if (check)
    return crc16;
  else {
    packet->checksum = crc16;
    return -1;
  }

}
