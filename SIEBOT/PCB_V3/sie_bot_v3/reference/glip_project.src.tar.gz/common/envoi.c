/*
 * envoi.c
 *
 * This module is used to send the different types of messages. It includes a
 * function that determines the ID of the blocks by looking in the array defined below.
 *
 * Copyright 2010 - Mickaël Camus <mickaelcamus.mc@gmail.com>,
 *                  Enzo Casasola <enzocasasola@gmail.com>,
 *                  Julie Estivie <juliestivie@gmail.com>,
 *                  Florent Matignon <florent.matignon@gmail.com>
 *
 * All rights reserved.
 * GLiP (Great LEDs interactive Puzzle)
 * Telecom ParisTech - ELECINF344/ELECINF381
 *
 * This file is part of GLiP Project.
 *
 * GLiP Project is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * GLiP Project is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with GLiP Project.  If not, see <http://www.gnu.org/licenses/>.
 *
 *
 */

// GLiP features
#include "envoi.h"
#include "constant.h"
#include "fatal.h"
#include "checksum.h"
#include "glip-animation.h"
#include "animationDescriptor.h"
#include "lfsr.h"

// Array that determines the ID of the block by looking the unique stm32 ID.
static const uint32_t table_ID[20] = {0x43193038,
                                      0x43193046,
                                      0x43193131,
                                      0x43193432,
                                      0x43193433,
                                      0x43193434,
                                      0x43193437,
                                      0x43193764,
                                      0x43193841,
                                      0x43202550,
                                      0x43203148,
                                      0x43233356,
                                      0x43234646,
                                      0x43234962,
                                      0x43252542,
                                      0x43252544,
                                      0x43252640,
                                      0x43256454,
                                      0x43193839,
                                      0x43193436};

// Array that gives the block's direction 
static const uint8_t interface_table[] = {4,2,3,1,2,3,1,4};

/*
 *
 * The functions below give the corresponding row / col of a block
 *
 */
static uint8_t block_row(unsigned int bloc)
{
  return (bloc-1) / (currentAnimation->nb_colonnes);
}

static uint8_t block_col(unsigned int bloc)
{
  return (bloc-1) % (currentAnimation->nb_colonnes);
}

static uint8_t my_row()
{
  return block_row(myMID);
}

static uint8_t my_col()
{
  return block_col(myMID);
}

/*
 *
 * This function sends the YOUARE packet. It transmits to the right and to the bottom
 *
 */
void send_neighbours(uint8_t YouAreID) {
    static Paquet packet;
    static uint8_t data[MAX_COMMAND_SIZE];
    initPaquet(&packet);
    data[0] = YouAreID;
    data[3] = numAnim;

    // Horizontal Transmission
    data[2] = HORIZONTAL;
    if(myMID % (currentAnimation->nb_colonnes) == 0)
        // Last col
        data[1] = 0;
    else
        data[1] = myMID+1;
    makePaquet(&packet,0,myID,1,YOUARE,data);
    transmitPaquet(&packet,interface_table[rotation]);

    // If we are in the first col, we send to the left a message YOUARE myID=0
    if (my_col() == 0) {
      data[1] = 0;
      makePaquet(&packet, 0, myID, 1, YOUARE, data);
      transmitPaquet(&packet, interface_table[(rotation + 2) % 4]);
    }

    // Vertical Transmission
    data[2] = VERTICAL;
    if(((myMID + (currentAnimation->nb_colonnes)) > ((currentAnimation->nb_colonnes)*(currentAnimation->nb_lignes))) ||
        (myMID == 0))
      // Last row
      data[1] = 0;
    else
      data[1] = myMID + (currentAnimation->nb_colonnes);
    makePaquet(&packet,0,myID,1,YOUARE,data);
    transmitPaquet(&packet,interface_table[rotation+4]);

    // If we are in the first row, we send to the top a message YOUARE myID=0
    if (my_row() == 0) {
      data[1] = 0;
      makePaquet(&packet, 0, myID, 1, YOUARE, data);
      transmitPaquet(&packet, interface_table[((rotation + 2) % 4) + 4]);
    }
}


/*
 *
 * This function sends a packet to other children blocks. So the
 * transmission goes to the right and to the bottom.
 *
 */
void send_to_destination(Paquet *paquet)
{
  // If the block is not in the animation, nothing to do
  if (myMID == 0)
    return;

  // Change from field to avoid bounces
  paquet->from = myID;
  calculateCRC16Paquet (paquet, 0);

  // Put the addresse in data[1]
  uint8_t target = paquet->data[1];

  // Send to horizontal and vertical if we are allowed to
  if (my_col() < block_col(target))
    transmitPaquet(paquet, interface_table[rotation]);
  if (my_row() < block_row(target))
    transmitPaquet(paquet, interface_table[rotation+4]);
}

/*
 *
 * This function sends a packet to the master. So the packet is send
 * to top and left.
 *
 */
void send_to_master(Paquet *paquet)
{
  if (myMID == 0)
    return;

  paquet->from = myID;
  calculateCRC16Paquet (paquet, 0);

  if (my_col() > 0)
    transmitPaquet(paquet, interface_table[(rotation + 2) % 4]);
  if (my_row() > 0)
    transmitPaquet(paquet, interface_table[((rotation + 2) % 4) + 4]);
}

/*
 *
 * This function returns the ID of the block in range 1 - 20.
 *
 */
uint8_t which_is_myID() {
    unsigned int myID = ID_ADDR;

    for (unsigned int i=0;i<20;i++)
        if (table_ID[i] == myID)
            return ((uint8_t) (i+1));
    return 0;
}

/*
 *
 * If the block is the master, it can send a desynchronize message.
 *
 */
#ifdef MASTER
void desynchronize_world()
{
  static Paquet packet;
  static uint8_t data[MAX_COMMAND_SIZE];

  initPaquet(&packet);

  for (unsigned int i = 2; i <= 20; i++) {
    data[0] = i;
    data[1] = i;
    *(unsigned int *)&data[2] = lfsr(32);
    makePaquet(&packet, 0, myID, 20, YOURTIME, data);
    send_to_destination(&packet);
  }
}
#endif
