/*
 * fatal.c
 *
 * This module is used for debug.
 *
 *
 * Copyright 2010 - Alexis Polti <alexis.polti@telecom-paristech.fr>
 *
 *
 * All rights reserved.
 * GLiP (Great LEDs interactive Puzzle)
 * Telecom ParisTech - ELECINF344/ELECINF381
 *
 * This file is part of GLiP Project.
 *
 * GLiP Project is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * GLiP Project is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with GLiP Project.  If not, see <http://www.gnu.org/licenses/>.
 *
 *
 */

#include "fatal.h"
#include <FreeRTOS.h>

void fatal_error(const char* nom_fichier, unsigned int line) {
	// Desactivation des IRQ FreeRTOS
	portDISABLE_INTERRUPTS();

	// Desactivation de toutes les IRQ
	__asm volatile("   msr basepri, %0\n"::"r"(1));

	// Die
	while(1) ;
}
