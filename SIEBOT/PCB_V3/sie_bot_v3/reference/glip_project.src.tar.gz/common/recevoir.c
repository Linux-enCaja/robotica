/*
 * recevoir.c
 *
 * This module configures what the blocks must do when they receive
 * a certain type of packet.
 * The type of the messages are given in the constant.h file.
 *
 *
 * Copyright 2010 - Mickaël Camus <mickaelcamus.mc@gmail.com>,
 *                  Enzo Casasola <enzocasasola@gmail.com>,
 *                  Julie Estivie <juliestivie@gmail.com>,
 *                  Florent Matignon <florent.matignon@gmail.com>
 *
 * All rights reserved.
 * GLiP (Great LEDs interactive Puzzle)
 * Telecom ParisTech - ELECINF344/ELECINF381
 *
 * This file is part of GLiP Project.
 *
 * GLiP Project is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * GLiP Project is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with GLiP Project.  If not, see <http://www.gnu.org/licenses/>.
 *
 *
 */

// FreeRTOS and STM32 features
#include <FreeRTOS.h>
#include <task.h>
#include <queue.h>

// GLiP features
#include "recevoir.h"
#include "envoi.h"
#include "constant.h"
#include "synchro.h"
#include "glip-animation.h"
#include "debug.h"
#include "fatal.h"

// Table for the directions
static const uint8_t orientation_table[] = {1,0,3,2,0,3,2,1};

/*
 *
 * This function gives the behaviour of the block when it receives a new
 * packet in the queue.
 *
 */
void receive () {

  static uint8_t data[MAX_DATA_SIZE];

  // If the block is not a master, we save the last IDs
#ifndef MASTER
  static uint8_t lastYouAreID = 0;
  static uint8_t lastPingID = 0;
  static uint8_t lastYourtimeID = 0;
#endif

  static uint8_t lastPongID = 0;

  for ( ;; ) {

    static Paquet paquet;

    xQueueReceive (xQueuePaquet, &paquet, portMAX_DELAY);
#ifndef MASTER
    unsigned int interface = paquet.data[20];
#endif // MASTER

    if (paquet.from != myID) {
      switch (paquet.mode) {

        // PONG Packet type
        case PONG: {
          // Check the validity of the packet
          if (paquet.data[0] == lastPongID)
            break;
          lastPongID = paquet.data[0];

#ifdef MASTER
          // The master receives a PONG, so it answers by giving
          // the local time after calculating the latency of the
          // PING+PONG
          uint32_t emissionTime = *(uint32_t *)&paquet.data[2];
          uint32_t new_time = current_time() + (current_time() - emissionTime) / 2;

          // The new packet is made from the one we received
          data[0] = paquet.data[0];
          data[1] = paquet.data[1];
          *(uint32_t *)&data[2] = new_time;
          initPaquet(&paquet);
          makePaquet(&paquet, 0, myID, 20, YOURTIME, data);
          send_to_destination(&paquet);
#else

          // If the block is not the master, the packet is transmitted to the others
          // without modification
          send_to_master(&paquet);

#endif // MASTER

          break;
        }

#ifndef MASTER

          // YOUARE packet type
        case YOUARE:

          if(paquet.data[0] != lastYouAreID) {
            if (numAnim == paquet.data[3] && currentAnimation->stopMap)
              break;
            lastYouAreID = paquet.data[0];
            // New position
            ENSURE(paquet.data[1] <= 20);
            myMID = paquet.data[1];
            // New direction
            ENSURE(paquet.data[2] <= VERTICAL);
            ENSURE(interface >= IRDA_MIN);
            ENSURE(interface < 5);
            rotation = orientation_table[2*(interface-1)+paquet.data[2]];
            // New animation
            numAnim = paquet.data[3];
            // Transmission to neighbours
            send_neighbours(lastYouAreID);
            animConfig();
          }
          break;

          // PING packet type
        case PING:

          if (paquet.data[0] == lastPingID)
            break;
          lastPingID = paquet.data[0];

          if (paquet.data[1] == myMID) {
            // Send a PONG packet to the master
            data[0] = paquet.data[0];  // msgId
            data[1] = myMID;
            memcpy(&data[2], &paquet.data[2], 4);
            makePaquet (&paquet, 0, myID, 20, PONG, data);
            send_to_master(&paquet);
          } else {
            send_to_destination(&paquet);
          }
          break;

          // YOURTIME packet type
        case YOURTIME:

          if (paquet.data[0] == lastYourtimeID)
            break;
          lastYourtimeID = paquet.data[0];
          if (paquet.data[1] == myMID)
            adjust_current_time(*(uint32_t *)&data[2]);
          else
            send_to_destination(&paquet);
          break;
#endif

        default:
          ENSURE(0);
          break;
      }
    }

  }
}
