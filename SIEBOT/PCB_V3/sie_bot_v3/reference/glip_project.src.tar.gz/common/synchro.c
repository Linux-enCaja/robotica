/*
 * synchro.c
 *
 * This module is used to synchronize all the blocks together. A timer
 * has the current hour of the block. When a certain type of message is
 * received, the local clock is changed to the one gived in the message.
 *
 *
 * Copyright 2010 - Micka�l Camus <mickaelcamus.mc@gmail.com>,
 *                  Enzo Casasola <enzocasasola@gmail.com>,
 *                  Julie Estivie <juliestivie@gmail.com>,
 *                  Florent Matignon <florent.matignon@gmail.com>
 *
 * All rights reserved.
 * GLiP (Great LEDs interactive Puzzle)
 * Telecom ParisTech - ELECINF344/ELECINF381
 *
 * This file is part of GLiP Project.
 *
 * GLiP Project is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * GLiP Project is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with GLiP Project.  If not, see <http://www.gnu.org/licenses/>.
 *
 *
 */

#include <stm32f10x.h>

#include <stdlib.h>
#include "synchro.h"

/*
 *
 * Maximum value beyond which the clock must be changed directly and no
 * progressively.
 * 100 * 100�s = 10ms = 1/4 of frame at 25Hz
 *
 */
#define TIME_THRESHOLD 100

// local clock
volatile uint32_t time_counter = 0;

/*
 *
 * Change the local clock depending on the THRESHOLD value
 *
 */
void adjust_current_time(uint32_t new_time)
{
  int64_t now = current_time();
  int64_t newt = new_time;
  if (abs(newt - now) > TIME_THRESHOLD)
    time_counter = new_time;
  else
    time_counter += (newt - now) / 2;
}

/*
 *
 * Timer initialization
 *
 */
void time_init()
{
  RCC->APB1ENR |= 1 << 2;   // clock
  TIM4->PSC = 0;
  TIM4->ARR = 7200;

  // IRQ
  NVIC->IP[30] = 16;
  NVIC->ISER[0] |= 1 << 30;

  TIM4->DIER = 1 << 0;

  TIM4->CR1 = 1 << 0;       // Start the timer
}

/*
 *
 * We used an external variable to store the counter because the stm32's timers
 * are on 16bits and we need 32bits.
 *
 */
void TIM4_IRQHandler () {
  TIM4->SR &= ~1;
  time_counter++;
}
