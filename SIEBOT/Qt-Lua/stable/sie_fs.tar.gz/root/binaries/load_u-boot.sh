sudo usbboot -f ./usbboot_2gb_nand.cfg -c "boot"
sudo usbboot -f ./usbboot_2gb_nand.cfg  -c "nprog 0 openwrt-xburst-qi_lb60-u-boot.bin 0 0 -n" 
